-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 09, 2019 at 06:27 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sgpgi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `admid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`admid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admid`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appointment`
--

CREATE TABLE IF NOT EXISTS `tbl_appointment` (
  `appointid` int(11) NOT NULL AUTO_INCREMENT,
  `patname` varchar(60) NOT NULL,
  `docid` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `appointdate` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`appointid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_appointment`
--

INSERT INTO `tbl_appointment` (`appointid`, `patname`, `docid`, `status`, `appointdate`, `date`) VALUES
(1, 'saumya', 1, 'Cancel', '2019-08-29', '2019-08-04'),
(2, 'amit', 1, 'Confirm', '2019-08-06', '2019-08-04'),
(3, 'asd', 1, 'Cancel', '2019-08-07', '2019-08-04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE IF NOT EXISTS `tbl_contact` (
  `conid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobileno` varchar(12) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`conid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`conid`, `name`, `email`, `mobileno`, `message`, `date`) VALUES
(1, 'amit', 'jamit6868@gmail.com', '8090252126', 'Hello Amit', '2019-08-01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doctor`
--

CREATE TABLE IF NOT EXISTS `tbl_doctor` (
  `docid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `specialization` varchar(60) NOT NULL,
  `experience` varchar(60) NOT NULL,
  `fees` varchar(15) NOT NULL,
  `address` varchar(60) NOT NULL,
  `timing` varchar(30) NOT NULL,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`docid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_doctor`
--

INSERT INTO `tbl_doctor` (`docid`, `name`, `fname`, `email`, `password`, `gender`, `specialization`, `experience`, `fees`, `address`, `timing`, `date`) VALUES
(1, 'amit j', 'vk jaiswal', 'jamit6868@gmail.com', '12', 'male', 'Surgion', '2Years', '1200', 'L 844', '7:00 A.M To 10:00 A.M', '2019-08-02'),
(2, 'rohit', 'sksingh', 'r@gmail.com', '345', 'male', 'Surgion', '5years', '2000', 'lko', '7:00 A.M To 10:00 A.M', '2019-08-02'),
(3, 'behna', 'behna ke papa', 'behna@gmail.com', '989', 'female', 'Eye Specialist', '5', '8999', 'fzd', '12:00 P.M To 2:00 P.M', '2019-08-02'),
(4, 'saumya', 'saumya ke papa', 'saumya@gmail.com', '000', 'female', 'Eye Specialist', '4', '7777', 'sdd', '12:00 P.M To 2:00 P.M', '2019-08-02'),
(5, 'danish', 'danishpapa', 'd@gmail.com', '666', 'male', 'Physician', '2Years', '3333', 'awee', '12:00 P.M To 2:00 P.M', '2019-08-02'),
(6, 'akash', 'akashpapa', 'aka@gmail.com', '44444', 'male', 'Physician', '9', '2222', 'loiuy', '4:00 P.M To 6:00 P.M', '2019-08-02'),
(7, 'vineet', 'vpapa', 'v@gmail.com', '9090', 'male', 'Orthopediation', '10', '23445', 'werty', '4:00 P.M To 6:00 P.M', '2019-08-02'),
(8, 'rakesh', 'rpapa', 'rak@gmail.com', '87877', 'male', 'Cardiologist', '18', '123456', 'asdfghj', '4:00 P.M To 6:00 P.M', '2019-08-02'),
(9, 'asd', 'sfsd', 'aaa@gmail.com', '0000', 'male', 'Cardiologist', '12', '2000', 'dfgh', '4:00 P.M To 6:00 P.M', '2019-08-08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patient`
--

CREATE TABLE IF NOT EXISTS `tbl_patient` (
  `patid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `mobileno` varchar(12) NOT NULL,
  `address` varchar(60) NOT NULL,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`patid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_patient`
--

INSERT INTO `tbl_patient` (`patid`, `name`, `fname`, `email`, `password`, `gender`, `mobileno`, `address`, `date`) VALUES
(1, 'saumya', 'spapa', 'saumya@gmail.com', '1234', 'female', '34567', 'sfdgh', '2019-08-02'),
(2, 'amit', 'vk jaiswal', 'jamit6868@gmail.com', '444', 'male', '123456', 'L 844', '2019-08-02'),
(3, 'aryan', 'apapa', 'aa@gmail.com', '999', 'male', '3456789', 'dfghjk', '2019-08-02'),
(4, 'paaa', 'erty', 'hg@gmail.com', '3433', 'male', '345678', 'wertyuiop', '2019-08-02'),
(5, 'abc', 'qwe', 'aaa@gmail.com', '8888', 'male', '3456789', 'dfghjk', '2019-08-02');
